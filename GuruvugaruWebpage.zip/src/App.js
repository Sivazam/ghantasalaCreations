import React from "react"
import './App.css';
// import { Typography } from "@mui/material";
import HomePage from "./HomePage";

function App() {
  return (
    <>
      <HomePage />
      
    </>
  );
}

export default App;
